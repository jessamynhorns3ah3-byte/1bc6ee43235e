# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(ErlangHotpatch src/ErlangHotpatch.cpp)
set_property(TARGET ErlangHotpatch PROPERTY CXX_STANDARD 11)
target_link_libraries(ErlangHotpatch lionss pthread)

add_executable(glslTranspile src/glslTranspile.cpp)
set_property(TARGET glslTranspile PROPERTY CXX_STANDARD 11)
target_link_libraries(glslTranspile lionss pthread)

add_executable(marmot src/marmot.cpp)
set_property(TARGET marmot PROPERTY CXX_STANDARD 11)
target_link_libraries(marmot lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(hashbrown-lite src/hashbrown-lite.cpp)
set_property(TARGET hashbrown-lite PROPERTY CXX_STANDARD 11)
target_link_libraries(hashbrown-lite lionss pthread)

add_executable(Cindersmith src/Cindersmith.cpp)
set_property(TARGET Cindersmith PROPERTY CXX_STANDARD 11)
target_link_libraries(Cindersmith lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

add_executable(noiseGate src/noiseGate.cpp)
set_property(TARGET noiseGate PROPERTY CXX_STANDARD 11)
target_link_libraries(noiseGate lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(graphite-owl src/graphite-owl.cpp)
set_property(TARGET graphite-owl PROPERTY CXX_STANDARD 11)
target_link_libraries(graphite-owl lionss pthread)

add_executable(hugepage_madv src/hugepage_madv.cpp)
set_property(TARGET hugepage_madv PROPERTY CXX_STANDARD 11)
target_link_libraries(hugepage_madv lionss pthread)

add_executable(maroon src/maroon.cpp)
set_property(TARGET maroon PROPERTY CXX_STANDARD 11)
target_link_libraries(maroon lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(WalgPush src/WalgPush.cpp)
set_property(TARGET WalgPush PROPERTY CXX_STANDARD 11)
target_link_libraries(WalgPush lionss pthread)

add_executable(cnv-segment src/cnv-segment.cpp)
set_property(TARGET cnv-segment PROPERTY CXX_STANDARD 11)
target_link_libraries(cnv-segment lionss pthread)

add_executable(istio_mtls src/istio_mtls.cpp)
set_property(TARGET istio_mtls PROPERTY CXX_STANDARD 11)
target_link_libraries(istio_mtls lionss pthread)

add_executable(skybox-dawn src/skybox-dawn.cpp)
set_property(TARGET skybox-dawn PROPERTY CXX_STANDARD 11)
target_link_libraries(skybox-dawn lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(spill-tempfile src/spill-tempfile.cpp)
set_property(TARGET spill-tempfile PROPERTY CXX_STANDARD 11)
target_link_libraries(spill-tempfile lionss pthread)

add_executable(VkDescriptor src/VkDescriptor.cpp)
set_property(TARGET VkDescriptor PROPERTY CXX_STANDARD 11)
target_link_libraries(VkDescriptor lionss pthread)

add_executable(cosineWarmup src/cosineWarmup.cpp)
set_property(TARGET cosineWarmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cosineWarmup lionss pthread)

add_executable(webpackCacheBust src/webpackCacheBust.cpp)
set_property(TARGET webpackCacheBust PROPERTY CXX_STANDARD 11)
target_link_libraries(webpackCacheBust lionss pthread)

add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

add_executable(GliderFleet src/GliderFleet.cpp)
set_property(TARGET GliderFleet PROPERTY CXX_STANDARD 11)
target_link_libraries(GliderFleet lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(quic-0rtt src/quic-0rtt.cpp)
set_property(TARGET quic-0rtt PROPERTY CXX_STANDARD 11)
target_link_libraries(quic-0rtt lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(basaltedge src/basaltedge.cpp)
set_property(TARGET basaltedge PROPERTY CXX_STANDARD 11)
target_link_libraries(basaltedge lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

