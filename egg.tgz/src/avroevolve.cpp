// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Check schema evolution\n", stdout);
  return lionss_run_workload("avroevolve");
}
