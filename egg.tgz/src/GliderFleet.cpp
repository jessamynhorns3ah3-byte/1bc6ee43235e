// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dispatch glider fleet\n", stdout);
  return lionss_run_workload("GliderFleet");
}
