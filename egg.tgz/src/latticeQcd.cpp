// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Thermalize lattice"); }
int main(){
  announce();
  return lionss_run_workload("latticeQcd");
}
