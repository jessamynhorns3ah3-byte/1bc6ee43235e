// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Segment copy number"); }
int main(){
  announce();
  return lionss_run_workload("cnv-segment");
}
